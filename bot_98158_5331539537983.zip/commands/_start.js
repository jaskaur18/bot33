/*CMD
  command: /start
  help: 
  need_reply: 
  auto_retry_time: 
  folder: 
  answer: 
  keyboard: 
  aliases: 
CMD*/

var button = [
    {title: "And what here??", url: "https://t.me/"}
];
Bot.sendInlineKeyboard(button,"tell me what text you want here????")
